export class Student {
  firstName: string;
  lastName: string;
  admissionYear: number;
  gradYear: number;

  constructor(firstName: string, lastName: string, admissionYear: number) {
    this.admissionYear = admissionYear;
    this.firstName = firstName;
    this.lastName = lastName;
    this.gradYear = admissionYear + 4;
  }
}
var student1 = new Student("firstName1", "lastName1", 2016);
var student2 = new Student("firstName2", "lastName2", 2017);
var student3 = new Student("firstName3", "lastName3", 2017);
var student4 = new Student("firstName4", "lastName4", 2018);
var student5 = new Student("firstName5", "lastName5", 2019);
var studentList = [];
studentList.push(student1);
studentList.push(student2);
studentList.push(student3);
studentList.push(student4);
studentList.push(student5);

printStudents(studentList);





function time2graduate(gradYear: number): number {
  var date = new Date();
  var timeLeft: number = gradYear - date.getFullYear();
  return timeLeft;
}

function printStudents(studentList: Student[]) {
  for (var i: number = 0; i < studentList.length; i++) {
    console.log(
      studentList[i].firstName +
        " " +
        studentList[i].lastName +
        " will graduate in " +
        time2graduate(studentList[i].gradYear) +
        " years"
    );
  }
}
