// （1） Give an example of Typescript object and class instance object and tell their difference.
class person {
  // is a typescript Object, any non primitive data type
  firstName: string;
  lastName: string;

  constructor(firstName: string, lastname: string) {
    (this.firstName = firstName), (this.lastName = lastname);
  }
}

var newPerson = new person("Mike", "Miranda"); // instance of a class object
// the typescript object is any non primitive type that is made upp of primitive or non primitive types
//the class instance object is an instance or a new creation of the invoked class

// （2） Define a product interface which has two attributes: name and price
interface product {
  name: string;
  price: string;
}

// （3） Create an array with 10 numbers, and then use three different ways to add them up
var nums = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
var sum: number = 0;

//#1
for (let j in nums) {
  sum += parseInt(j);
}
console.log(sum)

//#2
console.log(nums.reduce((a, b) => a + b, 0));


//#3
sum = 0;
var i: number = nums.length - 1;
while (i >= 0) {
  sum += nums[i];
  i--;
}
console.log(sum);


